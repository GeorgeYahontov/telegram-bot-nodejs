import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import {HttpModule} from "@nestjs/axios";
import {ConfigModule} from "@nestjs/config";
import {TelegramBotController} from "./telegram-bot/telegram-bot.controller";
import {OpenaiService} from "./openai/openai.service";
import * as Joi from 'joi';
@Module({

  imports: [HttpModule, // Добавляет HttpModule
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
      validationSchema: Joi.object({
        OPENAI_API_KEY: Joi.string().required(),
        TELEGRAM_BOT_TOKEN: Joi.string().required(),
      }),}), ],
  controllers: [AppController,TelegramBotController],
  providers: [AppService,OpenaiService],
})
export class AppModule {}
