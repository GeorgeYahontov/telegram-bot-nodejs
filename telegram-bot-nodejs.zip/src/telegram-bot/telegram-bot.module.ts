import { Module } from '@nestjs/common';
import {TelegramBotController} from "./telegram-bot.controller";
import {OpenaiModule} from "../openai/openai.module";
import {TelegramBotService} from "./telegram-bot.service";
@Module({
    imports: [OpenaiModule],
    controllers: [TelegramBotController],
    providers: [TelegramBotService],
    exports: [TelegramBotService]
})
export class TelegramBotModule {}
